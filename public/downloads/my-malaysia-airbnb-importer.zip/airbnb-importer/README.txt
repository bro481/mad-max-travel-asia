MAD MAX Malaysia Stay · Airbnb 图片导入扩展

安装：
1. 打开 chrome://extensions
2. 开启右上角“开发者模式”
3. 点击“加载已解压的扩展程序”
4. 选择本文件夹 airbnb-importer

使用：
1. 在 MAD MAX Malaysia Stay 后台房源图片页生成一次性导入码
2. 打开 Airbnb 房源页面（扩展会自动尝试打开并滚动完整相册）
3. 点击浏览器工具栏中的扩展，输入导入码
4. 点击“扫描并导入当前房源”

新版会持续滚动相册直到图片数量稳定，并显示识别、成功与失败数量。
Airbnb 页面扫描期间请不要关闭页面或切换标签。
